<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'Laravel') }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    @stack('styles')

    <style>
        .tooltip-safe {
            position: absolute;
            z-index: 9999;
        }

        /* ================= LOGO ANIMATION ================= */
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes floatLogo {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-6px);
            }
        }

        .logo-slide {
            animation: slideInLeft 0.8s ease-out;
        }

        .logo-float {
            animation: floatLogo 3s ease-in-out infinite;
        }

        /* ================= SIDEBAR TEXT ANIMATION ================= */
        @keyframes waveText {
            0% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(6px);
            }

            100% {
                transform: translateY(0);
            }
        }

        .menu-text span {
            display: inline-block;
        }

        .menu-item:hover .menu-text span {
            animation: waveText 0.4s ease-in-out;
        }

        /* ================= LIBRARY / DOWNLOAD WAVE ANIMATION ================= */
        @keyframes floatSlow {

            0%,
            100% {
                transform: translateY(0px) translateX(0px);
            }

            50% {
                transform: translateY(-20px) translateX(12px);
            }
        }

        @keyframes floatMedium {

            0%,
            100% {
                transform: translateY(0px) translateX(0px);
            }

            50% {
                transform: translateY(-14px) translateX(-10px);
            }
        }

        @keyframes floatFast {

            0%,
            100% {
                transform: translateY(0px) translateX(0px);
            }

            50% {
                transform: translateY(-10px) translateX(14px);
            }
        }

        @keyframes waveMove {
            0% {
                transform: translateX(0);
            }

            50% {
                transform: translateX(-20px);
            }

            100% {
                transform: translateX(0);
            }
        }

        @keyframes waveMoveReverse {
            0% {
                transform: translateX(0);
            }

            50% {
                transform: translateX(24px);
            }

            100% {
                transform: translateX(0);
            }
        }

        .animate-float-slow {
            animation: floatSlow 8s ease-in-out infinite;
        }

        .animate-float-medium {
            animation: floatMedium 6s ease-in-out infinite;
        }

        .animate-float-fast {
            animation: floatFast 4.5s ease-in-out infinite;
        }

        .animate-wave-x {
            animation: waveMove 9s ease-in-out infinite;
        }

        .animate-wave-x-reverse {
            animation: waveMoveReverse 11s ease-in-out infinite;
        }

        .animate-wave-line {
            animation: waveMove 7s ease-in-out infinite;
        }
    </style>
</head>

<body class="font-sans antialiased bg-[#F4F6FA]">

    <div class="min-h-screen">

        {{-- ================= NAVBAR ================= --}}
        <div id="navbar"
            class="fixed top-0 left-0 w-full h-20
               bg-white shadow pl-4 pr-10
               flex justify-between items-center
               z-50">

            <div class="flex items-center gap-4">
                <img src="{{ asset('images/danantara.png') }}" class="h-14 logo-slide logo-float">
                <img src="{{ asset('images/inka.png') }}" class="h-14 logo-slide logo-float">
            </div>

            <div class="relative">
                <div onclick="toggleProfile()" class="cursor-pointer flex items-center gap-4">

                    <div class="text-right">
                        <p class="text-xl font-semibold text-[#2BA6B6]">
                            {{ auth()->user()->name }}
                        </p>
                        <p class="text-sm text-gray-500">
                            {{ auth()->user()->role === 'admin' ? 'Admin' : 'User' }}
                        </p>
                    </div>

                    @if (auth()->user()->avatar)
                        <img src="{{ asset('storage/' . auth()->user()->avatar) }}"
                            class="w-10 h-10 rounded-full object-cover">
                    @else
                        <div
                            class="w-10 h-10 bg-[#8FA8D6] rounded-full flex items-center justify-center text-white font-bold">
                            {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                        </div>
                    @endif

                </div>

                <div id="profileMenu"
                    class="hidden absolute right-0 mt-3 w-44 bg-white shadow-lg rounded-lg overflow-hidden z-50">

                    <a href="{{ route('profile.index') }}" class="block px-4 py-2 hover:bg-gray-100">
                        Profil
                    </a>

                    <hr>

                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button class="w-full text-left px-4 py-2 hover:bg-gray-100 text-red-500">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </div>

        {{-- ================= SIDEBAR ================= --}}
        <div id="sidebar"
            class="fixed top-20 left-0 h-[calc(100vh-5rem)] w-56 bg-[#8FA8D6]
               rounded-tr-3xl rounded-br-3xl
               flex flex-col justify-between z-40 transition-all duration-300">

            <div class="p-5">

                <button onclick="toggleSidebar()" class="text-white text-2xl mb-8">
                    ☰
                </button>

                <div class="space-y-4">

                    <a href="{{ route('dashboard') }}"
                        class="menu-item flex items-center gap-3 bg-white py-2 px-3 rounded-lg shadow hover:shadow-md transition">
                        <span>🏠</span>
                        <span class="menu-text">Dashboard</span>
                    </a>

                    <a href="{{ route('aspek.gcg.index') }}"
                        class="menu-item flex items-center gap-3 bg-white py-2 px-3 rounded-lg shadow hover:shadow-md transition">
                        <span>📒</span>
                        <span class="menu-text">Aspek GCG</span>
                    </a>

                    <a href="{{ route('penilaian.index') }}"
                        class="menu-item flex items-center gap-3 bg-white py-2 px-3 rounded-lg shadow hover:shadow-md transition">
                        <span>📝</span>
                        <span class="menu-text">Penilaian</span>
                    </a>

                    <a href="{{ route('library.index') }}"
                        class="menu-item flex items-center gap-3 bg-white py-2 px-3 rounded-lg shadow hover:shadow-md transition">
                        <span>📚</span>
                        <span class="menu-text">Library</span>
                    </a>

                    <a href="{{ route('profile.index') }}"
                        class="menu-item flex items-center gap-3 bg-white py-2 px-3 rounded-lg shadow hover:shadow-md transition {{ request()->routeIs('profile.*') ? 'ring-2 ring-[#2BA6B6]' : '' }}">
                        <span>👤</span>
                        <span class="menu-text">Profil</span>
                    </a>

                </div>
            </div>
        </div>

        {{-- ================= MAIN ================= --}}
        <div id="mainContent" class="ml-56 transition-all duration-300">
            <main class="pt-28 px-10">
                @yield('content')
            </main>
        </div>
    </div>

    {{-- ================= SCRIPT ================= --}}
    <script>
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        let isOpen = true;

        function toggleSidebar() {
            if (isOpen) {
                sidebar.classList.replace('w-56', 'w-20');
                mainContent.classList.replace('ml-56', 'ml-20');
                document.querySelectorAll('.menu-text').forEach(el => el.classList.add('hidden'));
            } else {
                sidebar.classList.replace('w-20', 'w-56');
                mainContent.classList.replace('ml-20', 'ml-56');
                document.querySelectorAll('.menu-text').forEach(el => el.classList.remove('hidden'));
            }
            isOpen = !isOpen;
        }

        function toggleProfile() {
            document.getElementById('profileMenu').classList.toggle('hidden');
        }

        document.addEventListener('click', (e) => {
            const menu = document.getElementById('profileMenu');
            if (!e.target.closest('#profileMenu') && !e.target.closest('[onclick="toggleProfile()"]')) {
                menu.classList.add('hidden');
            }
        });

        document.querySelectorAll('.menu-text').forEach(el => {
            const text = el.innerText;
            el.innerHTML = '';

            text.split('').forEach((char, i) => {
                const span = document.createElement('span');
                span.innerText = char === ' ' ? '\u00A0' : char;
                span.style.animationDelay = `${i * 0.05}s`;
                el.appendChild(span);
            });
        });
    </script>

    @stack('scripts')

</body>

</html>
